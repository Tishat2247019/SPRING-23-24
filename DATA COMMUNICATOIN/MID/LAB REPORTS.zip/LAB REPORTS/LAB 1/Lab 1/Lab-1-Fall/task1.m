x = 0:pi/100:2*pi;
y = sin(x);
plot(x,y)
