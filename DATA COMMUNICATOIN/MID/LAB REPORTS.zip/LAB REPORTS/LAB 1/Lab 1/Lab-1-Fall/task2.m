x = 0:pi/100:2*pi;
y = sin(x);
plot(x,y)
xlabel('x');
ylabel('y');
title('y = sin(x)')