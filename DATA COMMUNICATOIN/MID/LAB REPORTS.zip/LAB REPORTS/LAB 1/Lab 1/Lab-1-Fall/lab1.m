clc
clear
x2=10